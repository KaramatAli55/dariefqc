<?php
$mod_strings["LBL_MARKUP_AMT"] = "Markup(%)";
$mod_strings["LBL_PST"] = "PST";
$mod_strings["LBL_PST_AMT"] = "PST Amount";
