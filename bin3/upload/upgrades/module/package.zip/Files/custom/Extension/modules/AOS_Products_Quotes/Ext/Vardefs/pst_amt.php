<?php
$dictionary['AOS_Products_Quotes']['fields']['pst_amt'] = array (
    'required' => '1',
    'name' => 'pst_amt',
    'vname' => 'LBL_PST_AMT',
    'type' => 'currency',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => true,
    'len' => '26,6',
);