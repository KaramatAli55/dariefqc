<?php
 // created: 2017-03-04 17:51:56
$dictionary['AOS_Products_Quotes']['fields']['vat_amt']['inline_edit']=true;
$dictionary['AOS_Products_Quotes']['fields']['vat_amt']['merge_filter']='disabled';
$dictionary['AOS_Products_Quotes']['fields']['vat_amt']['enable_range_search']=false;

 ?>