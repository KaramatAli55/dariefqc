<?php
 // created: 2017-03-04 18:06:15
$dictionary['AOS_Products_Quotes']['fields']['description']['inline_edit']=true;
$dictionary['AOS_Products_Quotes']['fields']['description']['comments']='Full text of the note';
$dictionary['AOS_Products_Quotes']['fields']['description']['merge_filter']='disabled';

 ?>