<?php

$dictionary['AOS_Quotes']['fields']['line_items']['function'] = array (
    'name' => 'custom_display_lines',
    'returns' => 'html',
    'include' => 'custom/modules/AOS_Products_Quotes/Line_Items.php',
);