<?php
 // created: 2017-03-04 17:55:44
$dictionary['AOS_Products_Quotes']['fields']['pst_amt_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['pst_amt_c']['labelValue']='PST Amount';

 ?>