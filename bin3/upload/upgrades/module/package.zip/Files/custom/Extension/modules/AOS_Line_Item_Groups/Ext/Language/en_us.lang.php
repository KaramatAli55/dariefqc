<?php
$mod_strings["LBL_PST_TAX_AMOUNT"] = "PST";
$mod_strings["LBL_PST_TAX_AMOUNT_USDOLLAR"] = "PST (USD)";
