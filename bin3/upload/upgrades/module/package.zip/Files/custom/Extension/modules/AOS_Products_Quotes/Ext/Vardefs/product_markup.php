<?php
$dictionary['AOS_Products_Quotes']['fields']['product_markup'] = array(
    'required' => false,
    'name' => 'product_markup',
    'vname' => 'LBL_MARKUP_AMT',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => true,
    'len' => '10'
);
