<?php
$mod_strings["LBL_COST_PRICE"] = "Cost";
$mod_strings["LBL_MARKUP_AMT"] = "Markup(%)";
$mod_strings["LBL_MARKUP_AMOUNT"] = "Markup Amount";
$mod_strings["LBL_PST_AMT"] = "PST Amount";
$mod_strings["LBL_PST_TAX_AMOUNT"] = "PST";
