<?php
 // created: 2017-03-04 17:52:08
$dictionary['AOS_Products_Quotes']['fields']['vat']['inline_edit']=true;
$dictionary['AOS_Products_Quotes']['fields']['vat']['merge_filter']='disabled';

 ?>