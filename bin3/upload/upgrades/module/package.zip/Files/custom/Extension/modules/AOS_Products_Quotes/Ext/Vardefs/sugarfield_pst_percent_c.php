<?php
 // created: 2017-03-04 17:54:03
$dictionary['AOS_Products_Quotes']['fields']['pst_percent_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['pst_percent_c']['labelValue']='PST';

 ?>